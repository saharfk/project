# project front End Todo:

- [x] building all the front end pages.
- [x] adding instructions for how to signing up (doctor & patient)
- [x] adding dataset
- [ ] importing dataset to backend
- [ ] adding the codepen account link in parinaz's links.
- [ ] adding a screenshot of the game in about page.
- [ ] adding screenshots of doctor and patient panel in home page.
- [ ] adding a how to play instruction in how to play page.
- [ ] blending fornt end to back end.
- [ ] creating game page.
